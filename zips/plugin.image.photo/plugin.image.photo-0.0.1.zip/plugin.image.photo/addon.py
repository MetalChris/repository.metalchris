#!/usr/bin/python
#
#
# Written by MetalChris
# Released under GPL(v2) or Later

import urllib, urllib2, xbmcplugin, xbmcaddon, xbmcgui, string, htmllib, os, platform, re, xbmcplugin, sys
from bs4 import BeautifulSoup
import calendar
import datetime
import html5lib


local_string = xbmcaddon.Addon(id='plugin.image.photo').getLocalizedString
selfAddon = xbmcaddon.Addon(id='plugin.image.photo')
translation = selfAddon.getLocalizedString
defaultfanart = 'special://home/addons/plugin.image.photo/fanart.jpg'
defaultimage = 'special://home/addons/plugin.image.photo/icon.png'
addon = xbmcaddon.Addon(id='plugin.image.photo')
addon_handle = int(sys.argv [1])
baseurl='http://photo.net/gallery/'
today=datetime.datetime.today()
oneday=datetime.timedelta(1)
day=today
confluence_views = [500,501,502,503,504,508,510,514]
index = 0


def cats():
        addDir('Daily Samples', baseurl, 10, defaultimage)
        #addDir('Recent Pictures', 'http://apod.nasa.gov/apod/archivepix.html', 50, defaultimage)
        addDir('Categories', baseurl, 15, defaultimage)
	#addDir('Search', 'http://apod.nasa.gov/cgi-bin/apod/apod_search?tquery=', 60, defaultimage)


#10
def today(url):
	html = get_html(url)
	soup = BeautifulSoup(html,'html.parser').find_all('div', {'class':'float-holder'})
	authors = BeautifulSoup(str(soup),'html.parser').find_all('a')[:-1]
	authors = authors[1::2]
	thumbs = re.compile('src="(.+?)"').findall(str(soup))
	titles = re.compile('<br>(.+?)<br>').findall(str(soup))
	for thumb, title, author in zip(thumbs, titles, authors):
	    title = title + ' by ' + striphtml(str(author))
	    photo_id = (thumb.rsplit('/')[-1]).replace('sm','lg')
	    image = 'http://gallery.photo.net/photo/' + photo_id
	    liz=xbmcgui.ListItem(unicode(title), iconImage=str(image),thumbnailImage=str(image))
	    liz.setInfo( type="Image", infoLabels={ "Title": name })
	    xbmcplugin.addDirectoryItem(handle=addon_handle,url=str(image),listitem=liz,isFolder=False)
	xbmcplugin.endOfDirectory(handle=addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)


#15
def sub_cats(url):
	html = get_html(url)
	soup = BeautifulSoup(html,'html.parser').find_all('div', {'id':'categories'})
	cats = BeautifulSoup(str(soup),'html.parser').find_all('li')
	for item in cats:
	    name = item.text
	    url = ('http://photo.net' + item.find('a')['href']).replace('&store_prefs_p=0', '&start_index=0&store_prefs_p=0')
            addDir(name, url, 20, defaultimage)
	print url
	xbmcplugin.endOfDirectory(handle=addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)
	

#20
def sub_images(name, url):
	html = get_html(url)
	soup = BeautifulSoup(html,'html5lib').find_all('div', {'class':'trp_photo'})
	index = re.compile('start_index=(.+?)&').findall(url)
	nextpage = url.split('&start')[0] + '&start_index=' + (str(int(index[0]) + 12)) + '&store_prefs_p=0'
	print '============INDEX ' + str(index)
	for item in soup:
	    try: title = item.find('img')['alt']
	    except KeyError:
		title = 'Untitled'
	    author = striphtml(str(item.find('div', {'class':'photog-name'})))
	    name = title + ' by ' + author.decode('utf-8')
	    link = item.find('a')['href']
	    photo_id = link.split('=')[-1]
	    image = 'http://gallery.photo.net/photo/' + photo_id + '-lg.jpg'
	    liz=xbmcgui.ListItem(unicode(name), iconImage=str(image),thumbnailImage=str(image))
	    liz.setInfo( type="Image", infoLabels={ "Title": name })
	    xbmcplugin.addDirectoryItem(handle=addon_handle,url=str(image),listitem=liz,isFolder=False)
	if len(soup) == 12:
            addDir('View More', nextpage, 20, defaultimage)
	else:
            addDir('Main Menu', nextpage, None, defaultimage)
	    
	xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[7])+")")
	xbmcplugin.endOfDirectory(handle=addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)


#50
def get_images(url):
	html = get_html(url)
	images=re.compile('href="(.+?)">(.+?)</').findall(html)
	x = 28; x = int(x)
	for link, name in images[3:x]:
	    link = 'http://apod.nasa.gov/apod/' + link
	    html = get_html(link)
	    try: image = 'http://apod.nasa.gov/apod/' + (re.compile('<IMG SRC="(.+?)"').findall(html))[0]
	    except IndexError:
		continue
	    liz=xbmcgui.ListItem(unicode(name), iconImage=str(image),thumbnailImage=str(image))
	    liz.setInfo( type="Image", infoLabels={ "Title": name })
	    xbmcplugin.addDirectoryItem(handle=addon_handle,url=str(image),listitem=liz,isFolder=False)
	xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[7])+")")
	xbmcplugin.endOfDirectory(handle=addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)


#60
def search(url):
	print iconimage
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
            search = keyb.getText()
            print 'search= ' + search
            url = url + search.replace(' ','+')
	    print url
	    html = get_html(url)
	    soup = BeautifulSoup(html,'html.parser').find_all('a')
	    print len(soup)
	    print soup[1]
	    for item in soup:
	        name = item.text.encode('raw_unicode_escape').decode("cp1252").strip()
		if not 'APOD' in name:
		    continue
	        link = item.get('href')
		if not 'http' in link:
	            link = 'http://apod.nasa.gov/apod/' + str(link)#.replace('calendar/S_','ap').replace('jpg','html')
	        html = get_html(link)
	        try: image = 'http://apod.nasa.gov/apod/' + str(re.compile('<IMG SRC="(.+?)"').findall(str(html))[0])
		except IndexError:
		    continue
	        liz=xbmcgui.ListItem(unicode(name), iconImage=str(image),thumbnailImage=str(image))
	        liz.setInfo( type="Image", infoLabels={ "Title": name })
	        xbmcplugin.addDirectoryItem(handle=addon_handle,url=str(image),listitem=liz,isFolder=False)
	    xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[7])+")")
	    xbmcplugin.endOfDirectory(handle=addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)


def striphtml(data):
    p = re.compile(r'<.*?>')
    return p.sub('', data)


def sanitize(data):
    output = ''
    for i in data:
        for current in i:
            if ((current >= '\x20') and (current <= '\xD7FF')) or ((current >= '\xE000') and (current <= '\xFFFD')) or ((current >= '\x10000') and (current <= '\x10FFFF')):
               output = output + current
    return output


def get_html(url):
    #s = requests.Session()
    #s.get(url)
    #r = s.get(url, headers=headers)
    #print(r.text.encode('utf-8'))[0:200]
    #print r.cookies
    req = urllib2.Request(url)
    #req.add_header('Host', 'photography.nationalgeographic.com')
    req.add_header('User-Agent','User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:44.0) Gecko/20100101 Firefox/44.0')
    #req.add_header('Referer', 'http://photography.nationalgeographic.com/photography')
    #req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')

    try:
        response = urllib2.urlopen(req)
        #print response
        html = response.read()
        response.close()
    except urllib2.HTTPError:
        response = False
        html = False
    return html


def addDir(name, url, mode, iconimage, fanart=False, infoLabels=True):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
        ok = True
        liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo(type="Image", infoLabels={"Title": name})
        #liz.setProperty('IsPlayable', 'true')
        if not fanart:
            fanart=defaultfanart
        liz.setProperty('fanart_image', fanart)
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
        return ok


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


def unescape(s):
    p = htmllib.HTMLParser(None)
    p.save_bgn()
    p.feed(s)
    return p.save_end()

	
params = get_params()
url = None
name = None
mode = None
cookie = None
iconimage = None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass

print "Mode: " + str(mode)
print "URL: " + str(url)
print "Name: " + str(name)

if mode == None or url == None or len(url) < 1:
    print "Generate Main Menu"
    cats()
elif mode == 10:
    print "Daily Samples"
    today(url)
elif mode == 15:
    print "Photo.net Subcategories"
    sub_cats(url)
elif mode == 20:
    print "Photo.net Subcategories"
    sub_images(name, url)
elif mode == 50:
    print "Indexing Images"
    get_images(url)
elif mode == 60:
    print "Search"
    search(url)
elif mode == 70:
    print "Get Episodes"
    get_episodes(url)
elif mode==520:
        print "Discovery Menu"
	dsc_free(url)
elif mode==525:
        print "TLC Menu"
	tlc_menu(url)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
xbmcplugin.endOfDirectory(handle=addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)
