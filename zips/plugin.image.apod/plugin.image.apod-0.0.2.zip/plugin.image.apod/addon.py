#!/usr/bin/python
#
#
# Written by MetalChris
# Released under GPL(v2) or Later

import urllib, urllib2, xbmcplugin, xbmcaddon, xbmcgui, string, htmllib, os, platform, re, xbmcplugin, sys
from bs4 import BeautifulSoup
import calendar
import datetime


local_string = xbmcaddon.Addon(id='plugin.image.apod').getLocalizedString
selfAddon = xbmcaddon.Addon(id='plugin.image.apod')
translation = selfAddon.getLocalizedString
defaultfanart = 'special://home/addons/plugin.image.apod/icon.png'
defaultimage = 'special://home/addons/plugin.image.apod/icon.png'
addon = xbmcaddon.Addon(id='plugin.image.apod')
addon_handle = int(sys.argv [1])
baseurl='http://apod.nasa.gov/apod/lib/aptree.html'
today=datetime.datetime.today()
oneday=datetime.timedelta(1)
day=today
confluence_views = [500,501,502,503,504,508,510,514]


def cats():
        addDir('Today\'s Picture', 'http://apod.nasa.gov/apod/astropix.html', 10, defaultimage)
        addDir('Recent Pictures', 'http://apod.nasa.gov/apod/archivepix.html', 50, defaultimage)
        addDir('Categories', baseurl, 15, defaultimage)
	addDir('Search', 'http://apod.nasa.gov/cgi-bin/apod/apod_search?tquery=', 60, defaultimage)


#10
def today(url):
	html = get_html(url)
	name = re.compile('<b>(.+?)</').findall(html)[0]
	image = 'http://apod.nasa.gov/apod/' + (re.compile('<IMG SRC="(.+?)"').findall(html))[0]
	liz=xbmcgui.ListItem(unicode(name), iconImage=str(image),thumbnailImage=str(image))
	liz.setInfo( type="Image", infoLabels={ "Title": name })
	xbmcplugin.addDirectoryItem(handle=addon_handle,url=str(image),listitem=liz,isFolder=False)
	xbmcplugin.endOfDirectory(handle=addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)


#15
def sub_cats(url):
	html = get_html(url)
	items = re.compile('<A HREF="(.+?)">(.+?)</').findall(html)
	for link, name in items:
	    if '<' in name:
		continue
	    url = 'http://apod.nasa.gov/apod/' + link.replace('../','')
            addDir(name, url, 20, defaultimage)
	xbmcplugin.endOfDirectory(handle=addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)
	

#20
def sub_images(url):
	html = get_html(url)
	soup = BeautifulSoup(html,'html.parser').find_all('img')
	print len(soup)
	print soup[1]
	for item in soup[1:]:
	    link = item.get('src')
	    #if 'gif' in link:
		#continue
	    link = 'http://apod.nasa.gov/apod/' + str(link).replace('calendar/S_','ap').replace('jpg','html')
	    name = item.text.encode('raw_unicode_escape').strip()
	    html = get_html(link)
	    image = 'http://apod.nasa.gov/apod/' + (re.compile('<IMG SRC="(.+?)"').findall(html))[0]
	    liz=xbmcgui.ListItem(unicode(name), iconImage=str(image),thumbnailImage=str(image))
	    liz.setInfo( type="Image", infoLabels={ "Title": name })
	    xbmcplugin.addDirectoryItem(handle=addon_handle,url=str(image),listitem=liz,isFolder=False)
	#xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[7])+")")
	xbmcplugin.endOfDirectory(handle=addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)


#50
def get_images(url):
	html = get_html(url)
	images=re.compile('href="(.+?)">(.+?)</').findall(html)
	x = 28; x = int(x)
	for link, name in images[3:x]:
	    link = 'http://apod.nasa.gov/apod/' + link
	    html = get_html(link)
	    try: image = 'http://apod.nasa.gov/apod/' + (re.compile('<IMG SRC="(.+?)"').findall(html))[0]
	    except IndexError:
		continue
	    name = item.text.encode('raw_unicode_escape').strip()
	    liz=xbmcgui.ListItem(unicode(name), iconImage=str(image),thumbnailImage=str(image))
	    liz.setInfo( type="Image", infoLabels={ "Title": name })
	    xbmcplugin.addDirectoryItem(handle=addon_handle,url=str(image),listitem=liz,isFolder=False)
	#xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[7])+")")
	xbmcplugin.endOfDirectory(handle=addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)


#60
def search(url):
	print iconimage
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
            search = keyb.getText()
            print 'search= ' + search
            url = url + search.replace(' ','+')
	    print url
	    html = get_html(url)
	    soup = BeautifulSoup(html,'html.parser').find_all('a')
	    print len(soup)
	    print soup[1]
	    for item in soup:
	        name = item.text.encode('raw_unicode_escape').decode("cp1252").strip()
		if not 'APOD' in name:
		    continue
	        link = item.get('href')
		if not 'http' in link:
	            link = 'http://apod.nasa.gov/apod/' + str(link)#.replace('calendar/S_','ap').replace('jpg','html')
	        html = get_html(link)
	        try: image = 'http://apod.nasa.gov/apod/' + str(re.compile('<IMG SRC="(.+?)"').findall(str(html))[0])
		except IndexError:
		    continue
	        liz=xbmcgui.ListItem(unicode(name), iconImage=str(image),thumbnailImage=str(image))
	        liz.setInfo( type="Image", infoLabels={ "Title": name })
	        xbmcplugin.addDirectoryItem(handle=addon_handle,url=str(image),listitem=liz,isFolder=False)
	    #xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[7])+")")
	    xbmcplugin.endOfDirectory(handle=addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)


def striphtml(data):
    p = re.compile(r'<.*?>')
    return p.sub('', data)


def sanitize(data):
    output = ''
    for i in data:
        for current in i:
            if ((current >= '\x20') and (current <= '\xD7FF')) or ((current >= '\xE000') and (current <= '\xFFFD')) or ((current >= '\x10000') and (current <= '\x10FFFF')):
               output = output + current
    return output


def get_html(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent','User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:44.0) Gecko/20100101 Firefox/44.0')

    try:
        response = urllib2.urlopen(req)
        html = response.read()
        response.close()
    except urllib2.HTTPError:
        response = False
        html = False
    return html


def addDir(name, url, mode, iconimage, fanart=False, infoLabels=True):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
        ok = True
        liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo(type="Image", infoLabels={"Title": name})
        #liz.setProperty('IsPlayable', 'true')
        if not fanart:
            fanart=defaultfanart
        liz.setProperty('fanart_image', fanart)
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
        return ok


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


def unescape(s):
    p = htmllib.HTMLParser(None)
    p.save_bgn()
    p.feed(s)
    return p.save_end()

	
params = get_params()
url = None
name = None
mode = None
cookie = None
iconimage = None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass

print "Mode: " + str(mode)
print "URL: " + str(url)
print "Name: " + str(name)

if mode == None or url == None or len(url) < 1:
    print "Generate Main Menu"
    cats()
elif mode == 10:
    print "Today\'s Pic"
    today(url)
elif mode == 15:
    print "APOD Subcategories"
    sub_cats(url)
elif mode == 20:
    print "APOD Subcategories"
    sub_images(url)
elif mode == 50:
    print "Indexing Images"
    get_images(url)
elif mode == 60:
    print "Search"
    search(url)
elif mode == 70:
    print "Get Episodes"
    get_episodes(url)
elif mode==520:
        print "Discovery Menu"
	dsc_free(url)
elif mode==525:
        print "TLC Menu"
	tlc_menu(url)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
xbmcplugin.endOfDirectory(handle=addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)
